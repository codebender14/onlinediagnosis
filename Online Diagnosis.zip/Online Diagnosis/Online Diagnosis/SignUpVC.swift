//
//  SignUpVC.swift
//  Online Diagnosis
//
//  Created by Chaparala,Naga Akhil on 5/30/23.
//

import UIKit
import FirebaseAuth
import FirebaseFirestore

class SignUpVC: UIViewController {

    // Access Firestore database
    let db = Firestore.firestore()
    
    @IBOutlet weak var firstNameTF: UITextField!
    @IBOutlet weak var middleNameTF: UITextField!
    @IBOutlet weak var lastNameTF: UITextField!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func SignUpBTN(_ sender: UIButton) {
        // Get user input from text fields
        guard let firstName = firstNameTF.text,
            let middleName = middleNameTF.text,
            let lastName = lastNameTF.text,
            let email = emailTF.text,
            let password = passwordTF.text else {
                // Handle invalid input
                displayAlert(message: "Please fill in all fields.")
                return
        }

        // Check if any field is empty
        if firstName.isEmpty {
            displayAlert(message: "Please enter your first name.")
            return
        }

        if lastName.isEmpty {
            displayAlert(message: "Please enter your last name.")
            return
        }

        if email.isEmpty {
            displayAlert(message: "Please enter your email.")
            return
        }

        if password.isEmpty {
            displayAlert(message: "Please enter your password.")
            return
        }

        // Create dictionary with user data
        let userData: [String: Any] = [
            "firstName": firstName,
            "middleName": middleName,
            "lastName": lastName,
            "email": email,
            "password": password
        ]

        Auth.auth().createUser(withEmail: email, password: password) {
            authResult, error  in
            if let error = error {
                // Handle error
                print("Error in creating account: \(error)")
                self.displayAlert(message: "Error signing up.")
            } else {
                // User data added successfully
                print("Successful sign up")
            }
        }
        

        // Add user data to a collection
        self.db.collection("users").addDocument(data: userData) { error in
            if let error = error {
                // Handle error
                print("Error adding document: \(error)")
                self.displayAlert(message: "Error signing up.")
            } else {
                // User data added successfully
                //self.displayAlert(message: "Sign up successful.")
                let listfeature = self.storyboard?.instantiateViewController(withIdentifier: "findfeature")as! FindFeaturesVC
                self.navigationController?.pushViewController(listfeature, animated: true)
            }
        }
    }

    // Helper method to display an alert
    func displayAlert(message: String) {
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        let okAction = UIAlertAction(title: "OK", style: .default, handler: nil)
        alert.addAction(okAction)
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func HaveAccountBTN(_ sender: UIButton) {
        let Login = self.storyboard?.instantiateViewController(withIdentifier: "login")as! LoginVC
        self.navigationController?.pushViewController(Login, animated: true)
    }
}
